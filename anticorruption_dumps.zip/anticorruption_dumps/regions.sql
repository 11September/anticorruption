-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 14 2017 г., 12:09
-- Версия сервера: 5.7.19-0ubuntu0.16.04.1
-- Версия PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `map`
--

-- --------------------------------------------------------

--
-- Структура таблицы `regions`
--

CREATE TABLE `regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name_ru` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ua` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `map_lat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `map_lng` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `regions`
--

INSERT INTO `regions` (`id`, `name_ru`, `name_ua`, `map_lat`, `map_lng`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Винницкая область', 'Вінницька область', '49.232788', '28.46888065', '', NULL, NULL),
(2, 'Волынская область', 'Волинська область', '50.74710089', '25.32550335', '', NULL, NULL),
(3, 'Днепропетровская область	', 'Дніпропетровська область', '48.46392972', '35.04784584', '', NULL, NULL),
(4, 'Донецкая область', 'Донецька область', '48.0157072', '37.80305386', '', NULL, NULL),
(5, 'Житомирская область', 'Житомирська область', '50.25439452', '28.65882397', '', NULL, NULL),
(6, 'Закарпатская область', 'Закарпатська область', '48.61747734', '22.29709625', '', NULL, NULL),
(7, 'Запорожская область', 'Запорізька область', '47.83839454', '35.13882637', '', NULL, NULL),
(8, 'Ивано-Франковская область', 'Івано-Франківська область', '48.92249926', '24.71026897', '', NULL, NULL),
(9, 'Киевская область', 'Київська область', '50.44930669', '30.52353859', '', NULL, NULL),
(10, 'Кировоградская область', 'Кіровоградська область', '48.50727935', '32.26349831', '', NULL, NULL),
(11, 'Луганская область', 'Луганська область', '48.57388128', '39.30762291', '', NULL, NULL),
(12, 'Львовская область', 'Львівська область', '49.83920028', '24.02907372', '', NULL, NULL),
(13, 'Николаевская область', 'Миколаївська область', '46.97334206', '31.99295998', '', NULL, NULL),
(14, 'Одесская область', 'Одеська область', '46.48220092', '30.72455406', '', NULL, NULL),
(15, 'Полтавская область', 'Полтавська область', '49.58784625', '34.55144405', '', NULL, NULL),
(16, 'Ровненская область', '	Рівненська область', '50.61940989', '26.25153065', '', NULL, NULL),
(17, 'Сумская область', 'Сумська область', '50.90763347', '34.79855061', '', NULL, NULL),
(18, 'Тернопольская область', 'Тернопільська область', '49.5528346', '25.59617043', '', NULL, NULL),
(19, 'Харьковская область', 'Харківська область', '49.98964247', '36.23205185', '', NULL, NULL),
(20, 'Херсонская область', 'Херсонська область', '46.63482219', '32.61660576', '', NULL, NULL),
(21, 'Хмельницкая область', 'Хмельницька область', '49.42147073', '26.98911667', '', NULL, NULL),
(22, 'Черкасская область', 'Черкаська область', '49.44424489', '32.05977917', '', NULL, NULL),
(23, 'Черниговская область', 'Чернігівська область', '51.49613345', '31.29026413', '', NULL, NULL),
(24, 'Черновицкая область', 'Чернівецька область', '48.29164536', '25.93648911', '', NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
