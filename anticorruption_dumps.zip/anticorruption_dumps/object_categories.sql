-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 14 2017 г., 12:09
-- Версия сервера: 5.7.19-0ubuntu0.16.04.1
-- Версия PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `map`
--

-- --------------------------------------------------------

--
-- Структура таблицы `object_categories`
--

CREATE TABLE `object_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `object_categories`
--

INSERT INTO `object_categories` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(13, 'житло', 'object-categories/September2017/MhKFEIZApB8ANGfJ9nUa.png', '2017-07-27 18:25:00', '2017-09-15 12:59:08'),
(14, 'медицина', 'object-categories/September2017/Xrid3oeOlTbUDpI3wdDw.png', '2017-07-27 18:27:00', '2017-09-15 12:58:14'),
(15, 'освіта', 'object-categories/September2017/b5hYcjtRCMVEmBXcWZxT.png', '2017-07-27 18:27:00', '2017-09-15 12:58:52'),
(16, 'майданчики', 'object-categories/September2017/LGCLPjBrqO9JBrXO5nse.png', '2017-07-27 18:27:00', '2017-09-13 06:27:10'),
(17, 'інфраструктура', 'object-categories/September2017/e2x4Nt24NwtI9u9jZ9Ft.png', '2017-07-27 18:27:00', '2017-09-13 06:28:21'),
(19, 'соціалка', 'object-categories/September2017/nWmfvRfFd15TyBUYEZud.png', '2017-08-03 13:12:00', '2017-09-15 12:57:52'),
(35, 'дороги', 'object-categories/November2017/FlTX5WYJpZ5SjiE9KJqX.png', '2017-11-07 09:41:45', '2017-11-07 09:41:45');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `object_categories`
--
ALTER TABLE `object_categories`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `object_categories`
--
ALTER TABLE `object_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
